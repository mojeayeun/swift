//
//  ViewController.swift
//  MyCripto
//
//  Created by h02 on 2017. 7. 31..
//  Copyright © 2017년 h02. All rights reserved.
//

import UIKit
import CryptoSwift

extension String {
    func aesEncrypt(key: String, iv: String) throws -> String {
        let data = self.data(using: .utf8)!
        let encrypted = try! AES(key: key, iv: iv, blockMode: .CBC, padding: PKCS7()).encrypt([UInt8](data))
        let encryptedData = Data(encrypted)
        return encryptedData.base64EncodedString()
    }
    
    func aesDecrypt(key: String, iv: String) throws -> String {
        let data = Data(base64Encoded: self)!
        let decrypted = try! AES(key: key, iv: iv, blockMode: .CBC, padding: PKCS7()).decrypt([UInt8](data))
        let decryptedData = Data(decrypted)
        return String(bytes: decryptedData.bytes, encoding: .utf8) ?? "Could not decrypt"
    }
}

class ViewController: UIViewController {

   
    @IBOutlet weak var txtMd5: UITextField!
    @IBOutlet weak var txtSHA512: UITextField!
    @IBOutlet weak var txtSHA255: UITextField!
    
    @IBOutlet weak var txtAES256: UITextField!
    @IBOutlet weak var txtAES256Key: UITextField!
    @IBOutlet weak var txtAES256Input: UITextField!
    
    var my_MD5Hash: String = ""
    var my_SHA512Hash: String = ""
    var my_SHA255Hash: String = ""
    var my_AESEncrypt: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
       
        txtAES256.text = "gqLOHUioQ0QjhuvI"
        txtAES256Key.text = "bbC2H19lkVbQDfakxcrtNMQdd0FloLyw"
    
    }

    
    @IBAction func test(_ sender: Any) {
        
        let iv = "gqLOHUioQ0QjhuvI" // length == 16
        txtAES256.text = iv
        
        
        let key = "bbC2H19lkVbQDfakxcrtNMQdd0FloLyw" // length == 32
        txtAES256Key.text = key
        
        
        let s = txtAES256Input.text!
        
        
        let enc = try! s.aesEncrypt(key: key, iv: iv)
        let dec = try! enc.aesDecrypt(key: key, iv: iv)
        
        print(s) // string to encrypt
        print("enc:\(enc)") // 2r0+KirTTegQfF4wI8rws0LuV8h82rHyyYz7xBpXIpM=
        print("dec:\(dec)") // string to encrypt
        print("\(s == dec)") // true
    }
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let DestViewContrller : ViewTwo = segue.destination as! ViewTwo
        
        
        my_MD5Hash = (txtMd5.text?.md5())!
        my_SHA512Hash = (txtSHA512.text?.sha512())!
        my_SHA255Hash = (txtAES256.text?.sha256())!
        
        
        
        let iv = txtAES256.text! // length == 16
        let key = txtAES256Key.text! // length == 32
        let s = txtAES256Input.text!
        
        
        let enc = try! s.aesEncrypt(key: key, iv: iv)
        let dec = try! enc.aesDecrypt(key: key, iv: iv)
        
        
        DestViewContrller.LabelMD5 = my_MD5Hash
        DestViewContrller.LabelSHA512 = my_SHA512Hash
        DestViewContrller.LabelSHA255 = my_SHA255Hash
        
        
        
        DestViewContrller.LabelAES256enc = enc
        DestViewContrller.LabelAES256dec = dec
        
        
        
        
        
        
    }


}

