//
//  ViewTow.swift
//  MyCripto
//
//  Created by h02 on 2017. 7. 31..
//  Copyright © 2017년 h02. All rights reserved.
//


import Foundation
import UIKit

class ViewTwo: UIViewController {
    
    
    @IBOutlet weak var lbMD5: UILabel!
    @IBOutlet weak var lbSHA512: UILabel!
    @IBOutlet weak var lbSHA255: UILabel!
    
    @IBOutlet weak var lbAES256enc: UILabel!
    @IBOutlet weak var lbAES256dec: UILabel!
    
    var LabelMD5 = String()
    var LabelSHA512 = String()
    var LabelSHA255 = String()
    var LabelAES256enc = String()
    var LabelAES256dec = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        lbMD5.text = LabelMD5
        lbSHA512.text = LabelSHA512
        lbSHA255.text = LabelSHA255
        
        
        lbAES256enc.text = LabelAES256enc
        lbAES256dec.text = LabelAES256dec
        
        
        
     }
    
        
    
}
