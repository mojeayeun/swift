//
//  Registration.swift
//  FinalProject
//
//  Created by h02 on 2017. 7. 31..
//  Copyright © 2017년 h02. All rights reserved.
//

import Foundation
import UIKit

import CryptoSwift

extension String {
    func aesEncrypt(key: String, iv: String) throws -> String {
        let data = self.data(using: .utf8)!
        let encrypted = try! AES(key: key, iv: iv, blockMode: .CBC, padding: PKCS7()).encrypt([UInt8](data))
        let encryptedData = Data(encrypted)
        return encryptedData.base64EncodedString()
    }
    
    func aesDecrypt(key: String, iv: String) throws -> String {
        let data = Data(base64Encoded: self)!
        let decrypted = try! AES(key: key, iv: iv, blockMode: .CBC, padding: PKCS7()).decrypt([UInt8](data))
        let decryptedData = Data(decrypted)
        return String(bytes: decryptedData.bytes, encoding: .utf8) ?? "Could not decrypt"
    }
}

class Registration: UIViewController {
    
    @IBOutlet weak var txtID: UITextField!
    @IBOutlet weak var txtPWD: UITextField!
    
    @IBOutlet weak var UserList: UITextView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initData()
        showData()
       
     }
    
   
    @IBAction func addUser(_ sender: Any) {
        
        let iv = "gqLOHUioQ0QjhuvI" // length == 16
        let key = "bbC2H19lkVbQDfakxcrtNMQdd0FloLyw" // length == 32

        let s = txtPWD.text!
        let enc = try! s.aesEncrypt(key: key, iv: iv)

        
        
        Repository.member_id.append(txtID.text!)
        Repository.member_pwd.append(enc)
        Repository.member_info.append("ID:" + txtID.text! + " Password: " + enc)
        
        
        initData()
        showData()
        
        
    }
    
    func initData(){
        let newId = String(Int(arc4random_uniform(UInt32(21) + 10)))
        txtID.text = newId
        txtPWD.text = ""
    }

    func showData(){
        UserList.text = ""
        for item in Repository.member_info {
            UserList.text =  UserList.text  + "[" + item + "]" + "\n"
        }

    }
    
    

    
    
}
