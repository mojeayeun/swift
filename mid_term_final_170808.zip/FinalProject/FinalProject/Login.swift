//
//  Login.swift
//  FinalProject
//
//  Created by h02 on 2017. 7. 31..
//  Copyright © 2017년 h02. All rights reserved.
//

import Foundation
import UIKit

class Login: UIViewController {
    
    @IBOutlet weak var txtID: UITextField!
    @IBOutlet weak var txtPWD: UITextField!
    
    @IBOutlet weak var lbResult: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func LoginBtn2(_ sender: Any) {
        let id = txtID.text!
        let pwd = txtPWD.text!
        
        var i = 0
        let iv = "gqLOHUioQ0QjhuvI" // length == 16
        let key = "bbC2H19lkVbQDfakxcrtNMQdd0FloLyw" // length == 32
        var tmp_pwd : String
        
        var retVal = false

        for item in Repository.member_id {
            
            if (item == id) {
                
                tmp_pwd = Repository.member_pwd[i]
                let dec = try! tmp_pwd.aesDecrypt(key: key, iv: iv)
                
                if (pwd == dec){
                    retVal = true;
                    break;
                }else{
                    break;
                }
            }
            i = i + 1
            
        }
        
        
        
        if (retVal) {
            lbResult.text =  "Login Success !!!!"
            let mainscreen = self.storyboard?.instantiateViewController(withIdentifier: "MainScreen")
            mainscreen?.modalTransitionStyle = UIModalTransitionStyle.coverVertical
            self.present(mainscreen!, animated: true, completion: nil)

        }else{
            lbResult.text = "Login Fail !!!!!"
       }

    }
  
    
//    @IBAction func LoginBtn(_ sender: Any) {
//        
//        let id = txtID.text!
//        let pwd = txtPWD.text!
//        
//        
//        var i = 0
//        
//        for item in Repository.member_id {
//            
//            if (item == id) {
//                if (pwd == Repository.member_pwd[i]){
//                    retVal = true;
//                    break;
//                }else{
//                    break;
//                }
//            }
//            i = i + 1
//            
//        }
//        
//        
//        if (retVal) {
//            lbResult.text =  "Login Success !!!!"
//            
//            let uvc = self.storyboard!.instantiateViewController(withIdentifier: "Main") // 1
//            uvc.modalTransitionStyle = UIModalTransitionStyle.crossDissolve // 2
//            self.present(uvc, animated: true) // 3
//            
//
//        
//        }else{
//            lbResult.text = "Login Fail !!!!!"
//        }
//        
//    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       
        
    }
    

    
    
    
    
}
