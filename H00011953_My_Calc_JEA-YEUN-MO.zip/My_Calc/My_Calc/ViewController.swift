//
//  ViewController.swift
//  My_Calc
//
//  Created by h02 on 2017. 9. 14..
//  Copyright © 2017년 h02. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
    
    @IBOutlet weak var operland1: UILabel!
    @IBOutlet weak var operland2: UILabel!
    @IBOutlet weak var calc_operator: UILabel!
    @IBOutlet weak var result: UILabel!
    
    @IBOutlet weak var prev_result: UILabel!
    @IBOutlet weak var prev_operator: UILabel!
    
    var operatorclickflag : Bool = false // 오퍼레이터가 눌려졌는지
    var calcflag : Bool = false  //== 가 눌려졌는지를 체크한다.
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initialize()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func initialize(){
        operland1.text = "0"
        operland2.text = "0"
        calc_operator.text = ""
        result.text = "0"
        prev_result.text = "0"
        prev_operator.text = ""
        
        operatorclickflag = false
        calcflag = false
    }
    
    //이전값을 제외하고 계산한다.
    func initialize2(){
        operland1.text = "0"
        operland2.text = "0"
        calc_operator.text = ""
        result.text = "0"
        
        operatorclickflag = false
        calcflag = false
    }
    

    @IBAction func touchDigit(_ sender: UIButton) {
      let digit = sender.currentTitle!
        
        if (calcflag) {
            initialize()
            operland1.text = digit
            return
        }  // = 이 눌려졌으면 다른것은 동작하면 안됨
        
      
        if (!operatorclickflag) {
            
            if check_dot(data: operland1.text, digit: digit){
                
            }else if check_zero_dot(data: operland1.text, digit: digit) {
                operland1.text = digit
            }else{
                operland1.text = operland1.text! + digit
            }
            
        }else{
            
            if check_dot(data: operland2.text, digit: digit){
                
            }else if check_zero_dot(data: operland2.text, digit: digit) {
                operland2.text = digit
            }else{
                operland2.text = operland2.text! + digit
            }
        }
     }
    
    func check_dot(data: String!, digit:String!) -> Bool{
        var retVal : Bool = false
        
        //. 이고, 이미 .가 있을경우 true return
        if (digit == "." &&  data.range(of: ".") != nil) {
            retVal = true
        }
   
        return retVal
        
   }
    

    func check_zero_dot(data: String!, digit:String!) -> Bool{
        var retVal : Bool = false
        
        
        if (data.characters.count == 1 &&  data == "0") {
           if (digit != ".") { retVal = true }
        }
        
        return retVal
    }
    
    
    //operator 연속계산
    @IBAction func touchOperator(_ sender: UIButton) {
        
        if (calcflag) {
            //= 계산이 된후에 계산된 값은 이전계산값으로 이동한다.
            prev_result.text = result.text
            
                
            initialize2()
            return
        
        }else if (operatorclickflag){
            // 이미 연산이 있었다면 perform을 수행하고, 이전값으로 이동시킨다.
            performcalc(Any)
            
            prev_result.text = result.text
            prev_operator.text = sender.currentTitle!
            
            initialize2()
            return
            
            //연속연산 처리 안됨
             //l. 4 + 5 × 3 = would show “4 + 5 × 3 =” (27 in the display)
            //m. 4 + 5 × 3 = could also show “(4 + 5) × 3 =” if you prefer (27 in the display)

        }
        
        calc_operator.text = sender.currentTitle
        operatorclickflag = true
    }
    
   
   
    
    @IBAction func performcalc(_ sender: Any) {
        calcflag = true
        
        print("do continous calc==> \(prev_result.text!)")
        print("do continous calc==> \(prev_operator.text!)")

        
        
        if (prev_result.text != "0" && prev_operator.text != ""){
            
            print("do continous calc")

            
            performTotalcalc()
        }else{
            
            
            print("do simple calc")

            performRealCalc()
        }
    }

    
    func performTotalcalc(){
        
        var ret_val: String
        
        ret_val = performSimpleCal(type: "1");
        
        print("first \(ret_val)")
        
        
//        ret_val = performSimpleCal(type: "2");
//        print("second \(ret_val)")
//        
        
        result.text = ret_val;
        
    }
    
    
    func performSimpleCal(type:String) -> String{
        let opt1 = prev_operator.text!
        let opt2 = calc_operator.text!
        
        var resultValString : String = ""
        var resultval : Float = 0
        var numberflag = true
        
        if (type == "1"){
        
            switch opt1 {
                case "X":
                    resultval = Float(prev_result.text!)! * Float(operland1.text!)!
                    break
                case "+":
                    resultval = Float(prev_result.text!)! + Float(operland1.text!)!
                    break
                case "-":
                    resultval = Float(prev_result.text!)! - Float(operland1.text!)!
                    break
                case "/":
            
                    if (Float(prev_result.text!)! == 0) {
                        resultval = 0
                    }else if (Float(operland1.text!)! == 0){
                        resultval = 0
                        numberflag = false
                    }else{
                        resultval = Float(prev_result.text!)! / Float(operland1.text!)!
                    }
                    break
                default:
                print("it is wrong prev_operator")
              
              }
            
            }else if (type == "2"){
                
                switch opt2 {
                    case "X":
                        resultval = Float(operland1.text!)! * Float(operland2.text!)!
                        break
                case "+":
                    resultval = Float(operland1.text!)! + Float(operland2.text!)!
                    break
                case "-":
                    resultval = Float(operland1.text!)! - Float(operland2.text!)!
                    break
                case "/":
                
                    if (Float(operland2.text!)! == 0) {
                        resultval = 0
                    }else if (Float(operland2.text!)! == 0){
                        resultval = 0
                        numberflag = false
                    }else{
                        resultval = Float(operland1.text!)! / Float(operland2.text!)!
                    }
                    break
                    
                default:
                    print("it is wrong calc operator")
                }
            
            
            }
        
        
        resultValString = execPoint(numberflag:numberflag, targetValue: String(resultval))
        return resultValString
        
    }
    
    
    func performRealCalc(){
        let opt = calc_operator.text!
        var resultval : Float = 0
        var numberflag = true
        
        
        switch opt {
        case "X":
            resultval = Float(operland1.text!)! * Float(operland2.text!)!
            result.text = String(resultval)
            break
        case "+":
            resultval = Float(prev_result.text!)! + Float(operland1.text!)! + Float(operland2.text!)!
            result.text = String(resultval)
            break
        case "-":
            resultval = Float(operland1.text!)! - Float(operland2.text!)!
            result.text = String(resultval)
            break
        case "/":
            
            if (Float(operland1.text!)! == 0) {
                result.text = "0"
            }else if (Float(operland2.text!)! == 0){
                result.text = "No Number"
                numberflag = false
            }else{
                resultval = Float(operland1.text!)! / Float(operland2.text!)!
                result.text = String(resultval)
            }
            break
            
        default:
            print("it is wrong menu")
      }
        
       
        result.text = execPoint(numberflag:numberflag, targetValue: result.text!)
        
        
    }
    
    
    func execPoint(numberflag : Bool, targetValue:String) -> String{
        let str = targetValue
        print("str: \(str)")
        
        let search = "."
        var return_value = targetValue
        
        //숫자이면서 , . 이 있으면
        if (numberflag && str.range(of: ".") != nil){
            // . 뒤로 부터 substring 하여 0 이면 0으로 표시하고, 그렇지 않으면 원래값을 표시한다.
            
            
            let range: Range<String.Index> = str.range(of: search)!
            let location : Int = str.distance(from: str.startIndex, to: range.lowerBound)
            
            //출처: http://devsc.tistory.com/56 [You Know Programing?]
            
            //print("location\(location) ")
            
            let index = str.index(str.startIndex, offsetBy: location)
            
            let beforedata = str.substring(to: index)
            let lastdata = "0" + str.substring(from: index)  // Swift
            
            //print("beforedata\(beforedata)  , lastdata\(lastdata)  ")
            
            
            if (Float(lastdata) == 0){
                return_value = String(beforedata)
            }else{
                return_value = String(beforedata) + str.substring(from: index)
            }
            
         }

        return return_value
        
    }
    
    @IBAction func calcRoot(_ sender: UIButton) {
        
        
        if (calcflag){
           // = 계산이 된후에 root가 눌려지면, 결과값에 root를 한다.
            
            let svalue = Float(result.text!)
            result.text = String(describing: svalue!.squareRoot())

            result.text = execPoint(numberflag:true, targetValue: result.text!)
            
        }else if (!operatorclickflag) { //operator가 클릭이전이면 앞에값에 root를 반영하고
            let svalue = Float(operland1.text!)
            operland1.text = String(describing: svalue!.squareRoot())
            
            operland1.text = execPoint(numberflag:true,targetValue: operland1.text!)
            
        }else{ //operator가 클릭 이후면 뒤에값에 root를 반영한다.
            let svalue = Float(operland2.text!)
            operland2.text = String(describing: svalue!.squareRoot())
            operland2.text = execPoint(numberflag:true,targetValue: operland2.text!)
        }

    
    }
    
    
    @IBAction func calcPie(_ sender: UIButton) {
        if (operatorclickflag && calc_operator.text == "X") {  //첫번째 연산자가 눌려지고, X인경우
            
          let area = M_PI * Double(operland1.text!)!
          operland2.text = String(M_PI)
          let targetValue = String(area)
          result.text = execPoint(numberflag:true, targetValue: targetValue)
            
        }
        
    }
    
    
    @IBAction func clear(_ sender: UIButton) {
        initialize()
    }
    
}

