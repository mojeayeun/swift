//
//  ViewController.swift
//  week3_multipage
//
//  Created by h02 on 2017. 9. 21..
//  Copyright © 2017년 h02. All rights reserved.
//

import UIKit



class ViewController: UIViewController {

    @IBOutlet weak var text1: UILabel!
    
    var myInt = Int()
    
    @IBOutlet weak var totoro_Image: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        myInt = 5
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // D    ispose of any resources that can be recreated.
    }


    @IBAction func goNext(_ sender: Any) {
        
                
        
        
        let myVC = storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! SecondVC
        myVC.stringPassed = text1.text!
        myVC.intPassed = myInt
        myVC.theImagePassed = totoro_Image.image!
        
        navigationController?.pushViewController(myVC, animated: true)
        
    }
    
    
    @IBAction func callhttp(_ sender: Any) {
        let myUrl = URL(string: "http://localhost/json/connect.php");
        
        var request = URLRequest(url:myUrl!)
        
        request.httpMethod = "POST"// Compose a query string
        
        let postString = "firstName=James&lastName=Bond";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            if error != nil
            {
                print("error=\(error)")
                return
            }
            
            // You can print out response object
            print("response = \(response)")
            
            //Let's convert response sent from a server side script to a NSDictionary object:
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                if let parseJSON = json {
                    
                    // Now we can access value of First Name by its key
                    let firstNameValue = parseJSON["firstName"] as? String
                    print("firstNameValue: \(firstNameValue)")
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
}

//https://code.tutsplus.com/tutorials/ios-sdk-passing-data-between-controllers-in-swift--cms-27151
