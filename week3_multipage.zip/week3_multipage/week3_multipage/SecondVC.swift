//
//  SecondVC.swift
//  week3_multipage
//
//  Created by h02 on 2017. 9. 21..
//  Copyright © 2017년 h02. All rights reserved.
//

import UIKit

class SecondVC: UIViewController {

    
    let secondLabel = UILabel()
    var stringPassed = ""
    
    var theImagePassed = UIImage()
    
    
    @IBOutlet weak var imagePassed: UIImageView!
    
    
    var intPassed = Int()
    
    @IBOutlet weak var receiveLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        receiveLabel.text = stringPassed + " my Int: \(intPassed)"
        
        imagePassed.image = theImagePassed
    }
    
    func testdata(){
        
    }
}
