//
//  Repository.swift
//  FinalProject
//
//  Created by h02 on 2017. 7. 31..
//  Copyright © 2017년 h02. All rights reserved.
//

import Foundation

public final class Repository {

    static var member_id = [String]()
    static var member_pwd = [String]()
    static var member_info = [String]()
    
}
